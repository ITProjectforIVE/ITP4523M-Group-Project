<?php
// Start the session
session_start();

// Database connection
$conn = new mysqli('127.0.0.1', 'root', '', 'projectDB');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'sid' exists in the cookie
if (!isset($_COOKIE['sid'])) {
    // Redirect to StaffLogin.php if 'sid' cookie does not exist
    header("Location: StaffLogin.php");
    exit;
}

// Get the 'sid' from the cookie
$sid = $_COOKIE['sid'];

// Check if the 'sid' exists in the staff table
$sql = "SELECT sid FROM staff WHERE sid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $sid);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    // Redirect to StaffLogin.php if 'sid' is invalid
    header("Location: StaffLogin.php");
    exit;
}

// Reset the 'sid' cookie expiration time to 1 hour
setcookie('sid', $sid, time() + 3600, '/');

// Get the 'oid' from the query parameter
if (!isset($_GET['oid'])) {
    die("Order ID not provided.");
}
$oid = intval($_GET['oid']);

// Fetch the order details
$orderQuery = "SELECT * FROM orders WHERE oid = ?";
$stmt = $conn->prepare($orderQuery);
$stmt->bind_param("i", $oid);
$stmt->execute();
$orderResult = $stmt->get_result();

if ($orderResult->num_rows === 0) {
    die("Order not found.");
}
$order = $orderResult->fetch_assoc();

// Fetch the product cost for the associated product ID
$pid = $order['pid'];
$productQuery = "SELECT pcost FROM product WHERE pid = ?";
$stmt = $conn->prepare($productQuery);
$stmt->bind_param("i", $pid);
$stmt->execute();
$productResult = $stmt->get_result();

if ($productResult->num_rows === 0) {
    die("Product not found.");
}
$product = $productResult->fetch_assoc();
$pcost = $product['pcost'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newOstatus = intval($_POST['ostatus']);
    $newOqty = intval($_POST['oqty']);
    $oldOstatus = $order['ostatus']; // Get the old order status

    // Validate ostatus value
    if (!in_array($newOstatus, [0, 1, 2, 3, 4, 5])) {
        $error = "Invalid ostatus. Only numbers between 0 and 5 are allowed.";
    } else {
        // Check material availability before updating the order
        $prodmatQuery = "SELECT pm.mid, pm.pmqty, m.mqty, m.mrqty 
                         FROM prodmat pm 
                         JOIN material m ON pm.mid = m.mid 
                         WHERE pm.pid = ?";
        $stmt = $conn->prepare($prodmatQuery);
        $stmt->bind_param("i", $pid);
        $stmt->execute();
        $prodmatResult = $stmt->get_result();

        if ($prodmatResult->num_rows > 0) {
            while ($row = $prodmatResult->fetch_assoc()) {
                $mid = $row['mid'];          // Material ID
                $pmqty = $row['pmqty'];      // Material required per product
                $mqty = $row['mqty'];        // Physical quantity
                $mrqty = $row['mrqty'];      // Reserved quantity

                // Calculate total required material for the new order quantity
                $requiredMaterial = $pmqty * $newOqty;

                // Check if available material is sufficient
                if (($mqty - $mrqty) < $requiredMaterial && $newOstatus !== 0) {
                    $error = "Insufficient stock for Material ID $mid. Cannot update order quantity.";
                    $conn->close();
                    echo "<p style='color: red;'>$error</p>";
                    exit();
                }
            }
        }

        // If ostatus is 0 (cancel order), release the reserved materials
        if ($newOstatus === 0) {
            $prodmatResult->data_seek(0); // Reset pointer to start
            while ($row = $prodmatResult->fetch_assoc()) {
                $mid = $row['mid'];
                $pmqty = $row['pmqty'];
                $oldOqty = $order['oqty']; // Old order quantity
                $releasedMaterial = $pmqty * $oldOqty;

                // Update `mrqty` to release reserved materials
                $updateMaterialQuery = "UPDATE material 
                                        SET mrqty = mrqty - $releasedMaterial 
                                        WHERE mid = ?";
                $stmt = $conn->prepare($updateMaterialQuery);
                $stmt->bind_param("i", $mid);
                $stmt->execute();
            }
        } elseif ($oldOstatus === 0 && $newOstatus !== 0) {
            // If ostatus changes from 0 to another value, reserve materials again
            $prodmatResult->data_seek(0); // Reset pointer to start
            while ($row = $prodmatResult->fetch_assoc()) {
                $mid = $row['mid'];
                $pmqty = $row['pmqty'];
                $oldOqty = $order['oqty']; // Old order quantity
                $reservedMaterial = $pmqty * $oldOqty;

                // Update `mrqty` to reserve materials again
                $updateMaterialQuery = "UPDATE material 
                                        SET mrqty = mrqty + $reservedMaterial 
                                        WHERE mid = ?";
                $stmt = $conn->prepare($updateMaterialQuery);
                $stmt->bind_param("i", $mid);
                $stmt->execute();
            }
        } else {
            // Adjust `mrqty` for updated order quantity
            $prodmatResult->data_seek(0); // Reset pointer to start
            while ($row = $prodmatResult->fetch_assoc()) {
                $mid = $row['mid'];
                $pmqty = $row['pmqty'];
                $oldOqty = $order['oqty']; // Old order quantity
                $qtyDifference = $newOqty - $oldOqty; // Difference in order quantity
                $adjustment = $pmqty * $qtyDifference;

                // Update `mrqty` in the database
                $updateMaterialQuery = "UPDATE material 
                                        SET mrqty = mrqty + $adjustment 
                                        WHERE mid = ?";
                $stmt = $conn->prepare($updateMaterialQuery);
                $stmt->bind_param("i", $mid);
                $stmt->execute();
            }
        }

        // Calculate the new ocost
        $newOcost = $newOqty * $pcost;

        // Update the order in the database
        $updateOrderQuery = "UPDATE orders SET ostatus = ?, oqty = ?, ocost = ? WHERE oid = ?";
        $stmt = $conn->prepare($updateOrderQuery);
        $stmt->bind_param("iidi", $newOstatus, $newOqty, $newOcost, $oid);

        if ($stmt->execute()) {
            $success = "Order updated successfully!";
        } else {
            $error = "Failed to update the order.";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Update Order</title>
</head>
<body>
    <div class="navbar">
        <ul>
            <li><a  href="index.html">Home</a></li>
            <li><a  href="ViewProduct.php">ViewProduct</a></li>
            <li><a  href="UpdateOrder.php">Order</a></li>
            <li><a  href="Report.php">Report</a></li>
            <li><a  href="Insert_Material.php">Insert Material</a></li>
        </ul>
    </div>

    <main>
        <h3>Update Order</h3>
        <div class="card">
            <?php if (isset($success)): ?>
                <p style="color: green;"><?= htmlspecialchars($success) ?></p>
            <?php elseif (isset($error)): ?>
                <p style="color: red;"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>

            <form action="UpdateOrder1.php?oid=<?= htmlspecialchars($oid) ?>" method="post">
                <label for="ostatus">Order Status:</label>
                <input type="number" id="ostatus" name="ostatus" value="<?= htmlspecialchars($order['ostatus']) ?>" min="0" max="5" required>
                <br />

                <label for="oqty">Order Quantity:</label>
                <input type="number" id="oqty" name="oqty" value="<?= htmlspecialchars($order['oqty']) ?>" required>
                <br />

                <button type="submit">Update Order</button>
            </form>
        </div>
    </main>
</body>
</html>