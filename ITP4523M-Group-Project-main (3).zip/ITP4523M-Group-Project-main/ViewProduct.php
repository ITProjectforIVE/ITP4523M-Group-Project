<?php
// Start session and handle cookies
session_start();

// Check if the 'sid' cookie exists
if (!isset($_COOKIE['sid'])) {
    header("Location: StaffLogin.php");
    exit;
}

// Database connection
$conn = new mysqli('127.0.0.1', 'root', '', 'projectDB');
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Validate 'sid' cookie with the database
$sid = $_COOKIE['sid'];
$sql = "SELECT * FROM staff WHERE sid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $sid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // If the staff ID is not found, redirect to login
    header("Location: StaffLogin.php");
    exit;
}

// Reset the cookie expiration time
setcookie('sid', $sid, time() + 3600, '/');

// Fetch all products from the database
$sql = "SELECT * FROM product";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Product</title>
    <style>
        /* General Styles */
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: url('Picture/Background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
        }

        .navbar {
            background-color: #333;
            overflow: hidden;
        }

        .navbar ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .navbar li {
            flex: 1;
        }

        .navbar a {
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #575757;
        }

        main {
            padding: 20px;
            text-align: center;
        }

        .card {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
            max-width: 800px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #f4f4f4;
            color: #333;
        }

        .update-button {
            background-color: #007bff;
            color: white;
            padding: 8px 12px;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
        }

        .update-button:hover {
            background-color: #0056b3;
        }

        .button-container {
            margin-top: 20px;
        }

        .button-container button {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        .button-container button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <ul>
            <li><a  href="index.html">Home</a></li>
            <li><a  href="ViewProduct.php">ViewProduct</a></li>
            <li><a  href="UpdateOrder.php">Order</a></li>
            <li><a  href="Report.php">Report</a></li>
            <li><a  href="Insert_Material.php">Insert Material</a></li>
        </ul>
    </div>
    <main>
        <h1>Product List</h1>
        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>Product ID</th>
                        <th>Product Name</th>
                        <th>Description</th>
                        <th>Cost</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['pid']) ?></td>
                                <td><?= htmlspecialchars($row['pname']) ?></td>
                                <td><?= htmlspecialchars($row['pdesc']) ?></td>
                                <td>$<?= htmlspecialchars(number_format($row['pcost'], 2)) ?></td>
                                <td>
                                    <a href="Update_Product.php?pid=<?= $row['pid'] ?>" class="update-button">Update</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5">No products found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="button-container">
            <button onclick="window.location.href='Insert_item.php'">Add New Product</button>
        </div>
    </main>
</body>
</html>

<?php
$conn->close();
?>