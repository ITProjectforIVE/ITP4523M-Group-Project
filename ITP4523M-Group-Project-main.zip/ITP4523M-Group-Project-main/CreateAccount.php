<?php
// Start session
session_start();

// Database connection
$conn = new mysqli('127.0.0.1', 'root', '', 'projectDB');
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Generate a new Customer ID (cid)
$sql = "SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_name = 'customer' AND table_schema = 'projectDB'";
$result = $conn->query($sql);
if ($result && $row = $result->fetch_assoc()) {
    $new_cid = $row['AUTO_INCREMENT'];
} else {
    die("Unable to generate Customer ID.");
}

// Handle form submission for creating a customer account
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_account'])) {
    $cname = $_POST['cname'];
    $cpassword = $_POST['cpassword'];
    $ctel = $_POST['ctel'];
    $caddr = $_POST['caddr'];
    $company = $_POST['company'];

    // Validate inputs
    if (empty($cname) || empty($cpassword) || empty($ctel) || empty($caddr) || empty($company)) {
        $message = "All fields are required!";
    } elseif (!is_numeric($ctel) || strlen($ctel) < 8) {
        $message = "Invalid contact number!";
    } else {
        // Insert customer data into the database
        $sql = "INSERT INTO customer (cname, cpassword, ctel, caddr, company) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssiss', $cname, $cpassword, $ctel, $caddr, $company);

        if ($stmt->execute()) {
            // Redirect to CustomerLogin.php after successful account creation
            header("Location: CustomerLogin.php");
            exit;
        } else {
            $message = "Error creating account: " . $stmt->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Customer Account</title>
    <link rel="stylesheet" href="style.css">
    <script>
        function validateForm() {
            const cname = document.getElementById('cname').value;
            const cpassword = document.getElementById('cpassword').value;
            const ctel = document.getElementById('ctel').value;
            const caddr = document.getElementById('caddr').value;
            const company = document.getElementById('company').value;

            if (!cname || !cpassword || !ctel || !caddr || !company) {
                alert("All fields are required!");
                return false;
            }
            if (isNaN(ctel) || ctel.length < 8) {
                alert("Invalid contact number!");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="navbar">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="ProductList.php">Product</a></li>
            <li><a href="CustomerLogin.php">Login</a></li>
        </ul>
    </div>

    <main>
        <h3>Create Customer Account</h3>
        <div class="card">
            <?php if (isset($message)): ?>
                <p style="color: red;"><?= htmlspecialchars($message) ?></p>
            <?php endif; ?>
            <form method="POST" onsubmit="return validateForm()">
                <label for="cid">Customer ID:</label>
                <input type="text" id="cid" name="cid" value="<?= $new_cid ?>" readonly>
                <br />
                <label for="cname">Customer Name:</label>
                <input type="text" id="cname" name="cname" placeholder="Enter your name" required>
                <br />
                <label for="cpassword">Password:</label>
                <input type="password" id="cpassword" name="cpassword" placeholder="Enter your password" required>
                <br />
                <label for="ctel">Contact Number:</label>
                <input type="text" id="ctel" name="ctel" placeholder="Enter your contact number" required>
                <br />
                <label for="caddr">Address:</label>
                <input type="text" id="caddr" name="caddr" placeholder="Enter your address" required>
                <br />
                <label for="company">Company Name:</label>
                <input type="text" id="company" name="company" placeholder="Enter your company name" required>
                <br />
                <button type="submit" name="create_account">Create Account</button>
            </form>
        </div>
    </main>
</body>
</html>