<?php
// Start session and check for 'sid' cookie
session_start();

// Redirect to StaffLogin.php if 'sid' cookie is not set
if (!isset($_COOKIE['sid'])) {
    header("Location: StaffLogin.php");
    exit;
}

// Database connection
$conn = new mysqli('127.0.0.1', 'root', '', 'projectDB');
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Validate 'sid' cookie with the database
$sid = $_COOKIE['sid'];
$sql = "SELECT * FROM staff WHERE sid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $sid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Redirect to StaffLogin.php if 'sid' is not found in database
    header("Location: StaffLogin.php");
    exit;
}

// Reset the cookie expiration time to 1 hour
setcookie('sid', $sid, time() + 3600, '/');

// Generate a new Product ID (pid)
$new_pid = null;
$sql = "SELECT AUTO_INCREMENT FROM information_schema.tables WHERE table_name = 'product' AND table_schema = 'projectDB'";
$result = $conn->query($sql);
if ($result && $row = $result->fetch_assoc()) {
    $new_pid = $row['AUTO_INCREMENT'];
}

// Handle form submission for inserting product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['insert_product'])) {
    $pname = $_POST['pname'];
    $pdesc = $_POST['pdesc'];
    $pcost = $_POST['pcost'];

    $sql = "INSERT INTO product (pname, pdesc, pcost) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssd', $pname, $pdesc, $pcost);

    if ($stmt->execute()) {
        $new_pid = $conn->insert_id; // Retrieve the auto-generated Product ID
        $message = "Product inserted successfully! Product ID: $new_pid";
    } else {
        $message = "Error inserting product: " . $stmt->error;
    }
}

// Handle form submission for inserting or updating product-material relation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['insert_prodmat'])) {
    $pid = $_POST['pid'];
    $mid = $_POST['mid'];
    $pmqty = $_POST['pmqty'];

    // Check if the record exists in the prodmat table
    $sql = "SELECT * FROM prodmat WHERE pid = ? AND mid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $pid, $mid);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Update the record if it exists
        $sql = "UPDATE prodmat SET pmqty = ? WHERE pid = ? AND mid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('iii', $pmqty, $pid, $mid);

        if ($stmt->execute()) {
            $message = "Product-material relation updated successfully!";
        } else {
            $message = "Error updating product-material relation: " . $stmt->error;
        }
    } else {
        // Insert a new record if it does not exist
        $sql = "INSERT INTO prodmat (pid, mid, pmqty) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('iii', $pid, $mid, $pmqty);

        if ($stmt->execute()) {
            $message = "Product-material relation inserted successfully!";
        } else {
            $message = "Error inserting product-material relation: " . $stmt->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Product and Product-Material Relation</title>
    <link rel="stylesheet" href="style.css">
    <script>
        function validateProductForm() {
            const pname = document.getElementById('pname').value;
            const pdesc = document.getElementById('pdesc').value;
            const pcost = document.getElementById('pcost').value;

            if (!pname || !pdesc || !pcost || isNaN(pcost) || pcost <= 0) {
                alert("Please fill out all fields correctly for the product!");
                return false;
            }
            return true;
        }

        function validateProdMatForm() {
            const pid = document.getElementById('pid').value;
            const mid = document.getElementById('mid').value;
            const pmqty = document.getElementById('pmqty').value;

            if (!pid || !mid || !pmqty || isNaN(pmqty) || pmqty <= 0) {
                alert("Please fill out all fields correctly for the product-material relation!");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="navbar">
        <ul>
        <li><a  href="index.html">Home</a></li>
            <li><a  href="ViewProduct.php">ViewProduct</a></li>
            <li><a  href="UpdateOrder.php">Order</a></li>
            <li><a  href="Report.php">Report</a></li>
            <li><a  href="Insert_Material.php">Insert Material</a></li>
        </ul>
    </div>
    <main>
        <h3>Insert Product</h3>
        <div class="card">
            <?php if (isset($message)): ?>
                <p style="color: green;"><?= htmlspecialchars($message) ?></p>
            <?php endif; ?>
            <form method="POST" onsubmit="return validateProductForm()">
                <input type="text" name="pname" id="pname" placeholder="Product Name" required>
                <br />
                <input type="text" name="pdesc" id="pdesc" placeholder="Product Description" required>
                <br />
                <input type="text" name="pcost" id="pcost" placeholder="Single Product Cost" required>
                <br />
                <button type="submit" name="insert_product">Add Product</button>
            </form>
        </div>

        <h3>Insert or Update Product-Material Relation</h3>
        <div class="card">
            <form method="POST" onsubmit="return validateProdMatForm()">
                <input type="text" name="pid" id="pid" placeholder="Product ID" required>
                <br />
                <input type="text" name="mid" id="mid" placeholder="Material ID" required>
                <br />
                <input type="text" name="pmqty" id="pmqty" placeholder="Material Quantity" required>
                <br />
                <button type="submit" name="insert_prodmat">Add or Update Relation</button>
            </form>
        </div>
    </main>
</body>
</html>