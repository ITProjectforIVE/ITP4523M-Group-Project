<?php
// Start the session
session_start();

// Database connection details
$hostname = "127.0.0.1";
$database = "projectDB";
$username = "root";
$password = "";

// Connect to the database
$conn = new mysqli($hostname, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the 'sid' cookie is set
if (!isset($_COOKIE['sid'])) {
    // Redirect to StaffLogin.php if 'sid' cookie does not exist
    header("Location: StaffLogin.php");
    exit;
}

// Get the sid from the cookie
$sid = $_COOKIE['sid'];

// Check if the sid exists in the database
$sql_sid_check = "SELECT sid FROM staff WHERE sid = ?";
$stmt_sid_check = $conn->prepare($sql_sid_check);
$stmt_sid_check->bind_param("i", $sid);
$stmt_sid_check->execute();
$result_sid_check = $stmt_sid_check->get_result();

if ($result_sid_check->num_rows === 0) {
    // Redirect to StaffLogin.php if the sid is not found
    header("Location: StaffLogin.php");
    exit;
}

// Reset the 'sid' cookie time to 1 hour (3600 seconds)
setcookie('sid', $sid, time() + 3600, '/');

// Query to fetch the required data for the sales report
$sql = "
    SELECT 
        orders.oid AS OrderID,
        product.pname AS ProductName,
        orders.oqty AS Quantity,
        orders.ocost AS TotalSalesAmount
    FROM orders
    INNER JOIN product ON orders.pid = product.pid
    ORDER BY orders.oid ASC
";

$result = $conn->query($sql);

// Check if there are results
$rows = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
}

// Close the database connection
$stmt_sid_check->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Sales Report</title>
</head>
<body>
    <div class="navbar">
        <ul>
        <li><a  href="index.html">Home</a></li>
            <li><a  href="ViewProduct.php">ViewProduct</a></li>
            <li><a  href="UpdateOrder.php">Order</a></li>
            <li><a  href="Report.php">Report</a></li>
        </ul>
    </div>
    <main>
        <h1>Sales Report</h1>
        <div class="card">
            <table id="report-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Total Sales Amount ($)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($rows)): ?>
                        <?php foreach ($rows as $row): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['OrderID']) ?></td>
                                <td><?= htmlspecialchars($row['ProductName']) ?></td>
                                <td><?= htmlspecialchars($row['Quantity']) ?></td>
                                <td><?= htmlspecialchars(number_format($row['TotalSalesAmount'], 2)) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4">No sales records found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>