<?php
// Start the session
session_start();

// Database connection details
$conn = new mysqli('127.0.0.1', 'root', '', 'projectDB');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the 'sid' cookie exists
if (!isset($_COOKIE['sid'])) {
    // Redirect to StaffLogin.php if 'sid' cookie does not exist
    header("Location: StaffLogin.php");
    exit;
}

// Get the 'sid' from the cookie
$sid = $_COOKIE['sid'];

// Check if the 'sid' exists in the staff table
$sql = "SELECT sid FROM staff WHERE sid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $sid);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    // Redirect to StaffLogin.php if 'sid' is invalid
    header("Location: StaffLogin.php");
    exit;
}

// Fetch all columns of the 'orders' table dynamically
$orderQuery = "SELECT * FROM orders";
$orderResult = $conn->query($orderQuery);

// Get column names dynamically
$columnsQuery = "SHOW COLUMNS FROM orders";
$columnsResult = $conn->query($columnsQuery);
$columns = [];
if ($columnsResult->num_rows > 0) {
    while ($column = $columnsResult->fetch_assoc()) {
        $columns[] = $column['Field'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Order List</title>
</head>
<body>
    <div class="navbar">
        <ul>
        <li><a  href="index.html">Home</a></li>
            <li><a  href="ViewProduct.php">ViewProduct</a></li>
            <li><a  href="UpdateOrder.php">Order</a></li>
            <li><a  href="Report.php">Report</a></li>
            <li><a  href="Insert_Material.php">Insert Material</a></li>
        </ul>
    </div>

    <main>
        <h3>Order List</h3>
        <div class="card">
            <table>
                <thead>
                    <tr>
                        <?php foreach ($columns as $column): ?>
                            <th><?= htmlspecialchars($column) ?></th>
                        <?php endforeach; ?>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($orderResult->num_rows > 0): ?>
                        <?php while ($row = $orderResult->fetch_assoc()): ?>
                            <tr>
                                <?php foreach ($columns as $column): ?>
                                    <td><?= htmlspecialchars($row[$column]) ?></td>
                                <?php endforeach; ?>
                                <td>
                                    <!-- Button to transfer oid to UpdateOrder1.php -->
                                    <a href="UpdateOrder1.php?oid=<?= $row['oid'] ?>">
                                        <button>Update</button>
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="<?= count($columns) + 1 ?>">No orders found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>