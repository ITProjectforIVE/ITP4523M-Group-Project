<?php
// Start session and check for 'sid' cookie
session_start();

// Redirect to StaffLogin.php if 'sid' cookie is not set
if (!isset($_COOKIE['sid'])) {
    header("Location: StaffLogin.php");
    exit;
}

// Database connection
$conn = new mysqli('127.0.0.1', 'root', '', 'projectDB');
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Validate 'sid' cookie with the database
$sid = $_COOKIE['sid'];
$sql = "SELECT * FROM staff WHERE sid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $sid);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Redirect to StaffLogin.php if 'sid' is not found in database
    header("Location: StaffLogin.php");
    exit;
}

// Check if 'pid' is set in the URL
if (!isset($_GET['pid']) || !is_numeric($_GET['pid'])) {
    die("Invalid Product ID.");
}

$pid = intval($_GET['pid']);

// Fetch product details
$sql = "SELECT pname, pdesc, pcost FROM product WHERE pid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $pid);
$stmt->execute();
$productResult = $stmt->get_result();

if ($productResult->num_rows === 0) {
    die("Product not found.");
}

$product = $productResult->fetch_assoc();
$message = "";

// Handle form submission for updating product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_product'])) {
    $pname = $_POST['pname'];
    $pdesc = $_POST['pdesc'];
    $pcost = $_POST['pcost'];

    if (!$pname || !$pdesc || !is_numeric($pcost) || $pcost <= 0) {
        $message = "Please fill out all fields correctly!";
    } else {
        $sql = "UPDATE product SET pname = ?, pdesc = ?, pcost = ? WHERE pid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssdi', $pname, $pdesc, $pcost, $pid);

        if ($stmt->execute()) {
            $message = "Product updated successfully!";
            // Refresh product details
            $product['pname'] = $pname;
            $product['pdesc'] = $pdesc;
            $product['pcost'] = $pcost;
        } else {
            $message = "Error updating product: " . $stmt->error;
        }
    }
}

// Handle product deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_product'])) {
    // Check if there are any orders associated with this product
    $sql = "SELECT COUNT(*) AS order_count FROM orders WHERE pid = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $pid);
    $stmt->execute();
    $orderCheckResult = $stmt->get_result();
    $orderCheck = $orderCheckResult->fetch_assoc();

    if ($orderCheck['order_count'] > 0) {
        $message = "Error: Cannot delete product because it is associated with existing orders.";
    } else {
        // Delete related prodmat entries
        $sql = "DELETE FROM prodmat WHERE pid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $pid);
        $stmt->execute();

        // Delete the product itself
        $sql = "DELETE FROM product WHERE pid = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $pid);

        if ($stmt->execute()) {
            $message = "Product and related materials deleted successfully!";
            header("Location: ViewProduct.php"); // Redirect to product list page after deletion
            exit;
        } else {
            $message = "Error deleting product: " . $stmt->error;
        }
    }
}

// Fetch related prodmat records
$sql = "SELECT pm.mid, m.mname, pm.pmqty 
        FROM prodmat pm 
        JOIN material m ON pm.mid = m.mid 
        WHERE pm.pid = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $pid);
$stmt->execute();
$prodmatResult = $stmt->get_result();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="navbar">
        <ul>
        <li><a  href="index.html">Home</a></li>
            <li><a  href="ViewProduct.php">ViewProduct</a></li>
            <li><a  href="UpdateOrder.php">Order</a></li>
            <li><a  href="Report.php">Report</a></li>
            <li><a  href="Insert_Material.php">Insert Material</a></li>
        </ul>
    </div>

    <main>
        <h3>Update Product</h3>
        <div class="card">
            <?php if (!empty($message)): ?>
                <p style="color: red;"><?= htmlspecialchars($message) ?></p>
            <?php endif; ?>
            <form method="POST">
                <label for="pid">Product ID:</label>
                <input type="text" id="pid" name="pid" value="<?= $pid ?>" readonly>
                <br />
                <label for="pname">Product Name:</label>
                <input type="text" id="pname" name="pname" value="<?= htmlspecialchars($product['pname']) ?>" required>
                <br />
                <label for="pdesc">Product Description:</label>
                <input type="text" id="pdesc" name="pdesc" value="<?= htmlspecialchars($product['pdesc']) ?>" required>
                <br />
                <label for="pcost">Product Cost:</label>
                <input type="text" id="pcost" name="pcost" value="<?= htmlspecialchars($product['pcost']) ?>" required>
                <br />
                <button type="submit" name="update_product">Update Product</button>
                <button type="submit" name="delete_product" onclick="return confirm('Are you sure you want to delete this product?')">Delete Product</button>
            </form>
        </div>

        <h3>Related Product-Material Information</h3>
        <div class="card">
            <?php if ($prodmatResult->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Material ID</th>
                            <th>Material Name</th>
                            <th>Required Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $prodmatResult->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($row['mid']) ?></td>
                                <td><?= htmlspecialchars($row['mname']) ?></td>
                                <td><?= htmlspecialchars($row['pmqty']) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No related materials found for this product.</p>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>